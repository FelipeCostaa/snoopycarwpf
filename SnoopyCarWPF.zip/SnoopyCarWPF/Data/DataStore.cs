﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using SnoopyCarWPF.Models;

namespace SnoopyCarWPF.Data
{
    public static class DataStore
    {
        public static ObservableCollection<Cliente> Clientes { get; set; }
        public static ObservableCollection<Produto> Produtos { get; set; }
        public static ObservableCollection<Agendamento> Agendamentos { get; set; }

        static DataStore()
        {
            // Inicializa as listas e adiciona dados de exemplo
            Clientes = new ObservableCollection<Cliente>
            {
                new Cliente { Nome = "João Silva", Telefone = "37999998888", Endereco = "Rua A, 123", Veiculo = "Fiat Palio" },
                new Cliente { Nome = "Maria Souza", Telefone = "37988887777", Endereco = "Rua B, 456", Veiculo = "Honda Civic" }
            };

            Produtos = new ObservableCollection<Produto>
            {
                new Produto { Nome = "Shampoo Automotivo", Quantidade = 10 },
                new Produto { Nome = "Cera de Carnaúba", Quantidade = 5 }
            };

            Agendamentos = new ObservableCollection<Agendamento>();
        }
    }
}
