﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnoopyCarWPF.Models
{
    public class Agendamento : INotifyPropertyChanged
    {
        public Cliente ClienteAgendado { get; set; }

        private DateTime _dataHora;
        public DateTime DataHora
        {
            get { return _dataHora; }
            set { _dataHora = value; OnPropertyChanged("DataHora"); }
        }

        private string _status;
        public string Status // "Agendado", "Concluído", "Cancelado"
        {
            get { return _status; }
            set { _status = value; OnPropertyChanged("Status"); }
        }

        public string NomeCliente => ClienteAgendado?.Nome;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
